import React from 'react'
import Nav_Bar from './Nav_Bar'

export default function Home() {
  return (
    <div><Nav_Bar/></div>
  )
}
