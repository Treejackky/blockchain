
import Nav_Bar from './Nav_Bar'
import { useState, React } from 'react'
import axios from 'axios'

export default function Register() {

    const [username, setUsername] = useState('')
    const [password, setPassword] = useState('')

    const register = () => {
        axios.post('http://localhost:5000/register', {
            username: username,
            password: password
        }).then((response) => {
            console.log(response);
        });
    };
    console.log(username);
    console.log(password);


  return (
    <div>
        <Nav_Bar/>
        <div className='container'>
        <br/>
        <center><h1> Register </h1></center>
        <form>
            <div className='mb-3'>
                <label className='form-label'>Username</label>
                <input type='text' className='form-control' id=''  onChange={e => setUsername(e.target.value)}/>
                <label className='form-label'>Password</label>
                <input type='password' className='form-control' id=''  onChange={e => setPassword(e.target.value)}/><br/>
                <button className='btn btn-primary' type='submit' onClick={register}>Submit</button>
            </div>
        </form>
    </div>
    </div>
  )
}
